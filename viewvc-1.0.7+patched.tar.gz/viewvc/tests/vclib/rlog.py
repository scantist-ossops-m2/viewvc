#!/usr/local/bin/python
import sys, os.path
sys.path.append( os.path.normpath(os.path.join(sys.path[0],"..","..","lib")) )
import vclib.ccvs
import popen
